// src/routes/biker/Search/SearchResults.jsx
import React, { useEffect, useMemo, useRef, useState } from "react";
import PhotoLightbox from "../../../components/PhotoLightbox.jsx";
import { useCart } from "../../../state/CartContext.jsx";
import { supabase } from "../../../lib/supabaseClient";

/* ================= Utils ================= */
const fmtDate = (iso) => {
  const d = new Date(iso);
  return isNaN(d) ? "" : d.toLocaleDateString("es-GT", { year: "numeric", month: "short", day: "2-digit" });
};
const fmtTime = (iso) => {
  const d = new Date(iso);
  return isNaN(d) ? "--:--" : d.toLocaleTimeString("es-GT", { hour: "2-digit", minute: "2-digit" });
};
const norm = (s) => String(s || "").normalize("NFD").replace(/\p{Diacritic}/gu, "").trim().toLowerCase();

const fileNameFrom = (item) => {
  if (item?.id && typeof item.id === "string" && item.id.includes("/")) {
    const clean = item.id.split("?")[0];
    return decodeURIComponent(clean.split("/").pop() || item.id);
  }
  if (item?.url) {
    const u = String(item.url).split("?")[0];
    const last = u.split("/").pop() || "";
    return decodeURIComponent(last);
  }
  return String(item?.id || "");
};

function toNumberQ(v) {
  if (typeof v === "number" && isFinite(v)) return Math.round(v);
  const s = String(v ?? "").replace(/\s+/g, "").replace(/,/g, "."); // soportar "10,00"
  const only = s.replace(/[^\d.]/g, "");
  const n = Number(only);
  return Number.isFinite(n) ? Math.round(n) : NaN;
}

/* ==== Normalizar tiers (legacy y listas nuevas) ==== */
function normalizeTiersLegacy(preciosJson) {
  if (!Array.isArray(preciosJson)) return [];
  const out = [];
  for (const raw of preciosJson) {
    if (!raw || typeof raw !== "object") continue;
    const n = Number(raw.n ?? raw.min ?? raw.qty ?? raw.desde ?? raw.cant ?? raw.cantidad ?? NaN);
    const pRaw = raw.precio ?? raw.price_q ?? raw.price ?? raw.valor ?? raw.value;
    const p = toNumberQ(pRaw);
    if (!Number.isFinite(p)) continue;
    const min = Number.isFinite(n) ? Math.max(1, Math.floor(n)) : (out.length ? out[out.length - 1].min + 1 : 1);
    out.push({ min, price: p });
  }
  out.sort((a, b) => a.min - b.min);
  const compact = [];
  for (const t of out) {
    if (compact.length && compact[compact.length - 1].min === t.min) compact[compact.length - 1] = t;
    else compact.push(t);
  }
  return compact;
}

function normalizeTiersFromList(listObj) {
  if (!listObj || typeof listObj !== "object") return [];
  const items = Array.isArray(listObj.items) ? listObj.items : [];
  const tiers = [];
  for (const raw of items) {
    if (!raw || typeof raw !== "object") continue;
    const n = Number(raw.n ?? raw.min ?? raw.qty ?? raw.cantidad ?? raw.cant ?? raw.desde ?? NaN);
    const pRaw = raw.precio ?? raw.price_q ?? raw.price ?? raw.valor ?? raw.value ?? raw.monto;
    const p = toNumberQ(pRaw);
    if (!Number.isFinite(p)) continue;
    const min = Number.isFinite(n) ? Math.max(1, Math.floor(n)) : (tiers.length ? tiers[tiers.length - 1].min + 1 : 1);
    tiers.push({ min, price: p });
  }
  tiers.sort((a, b) => a.min - b.min);
  const compact = [];
  for (const t of tiers) {
    if (compact.length && compact[compact.length - 1].min === t.min) compact[compact.length - 1] = t;
    else compact.push(t);
  }
  return compact;
}

/* ===== Bundle rules =====
 * - Si qty coincide con un escalón, usar ese precio TOTAL.
 * - Si qty > último escalón: mantener precio por foto del último escalón (constante).
 * - Si qty cae entre escalones (raro si definen 1..10), interpolación lineal segura.
 */
function bundleTotalForQty(tiers, q) {
  if (!tiers || !tiers.length) return 50 * Math.max(1, q); // fallback seguro
  const qty = Math.max(1, Number(q) || 1);
  const sorted = tiers.slice().sort((a, b) => a.min - b.min);

  // Match exacto
  const exact = sorted.find((t) => t.min === qty);
  if (exact) return exact.price;

  const first = sorted[0];
  const last = sorted[sorted.length - 1];

  // Debajo del primero: usa precio unit del primero
  if (qty < first.min) {
    const unit = first.price / first.min;
    return Math.round(unit * qty);
  }

  // Entre escalones: interpolación
  for (let i = 0; i < sorted.length - 1; i++) {
    const a = sorted[i], b = sorted[i + 1];
    if (qty > a.min && qty < b.min) {
      const gap = b.min - a.min;
      const step = (b.price - a.price) / gap;
      return Math.round(a.price + step * (qty - a.min));
    }
  }

  // Sobre el último: precio por foto del último escalón (constante)
  const unit = last.price / last.min;
  return Math.round(unit * qty);
}

/** Precio promedio por foto (para badge SI está seleccionada o si se agrega) */
function perItemAvgForQty(tiers, q) {
  const total = bundleTotalForQty(tiers, q);
  return Math.max(1, Math.round(total / Math.max(1, q)));
}

/* =================== Componente =================== */
export default function SearchResults({
  paginatedPhotos,
  totalPhotos,
  onLoadMore,
  hasMorePhotos,
  onToggleSel,
  selected,
  resolvePhotographerName,
  resolveHotspotName,
  totalQ,            // fallback del padre si aún no tenemos precios
  clearSel,
  cols = 6,
  showLabels = false,
}) {
  /* ---- cache de precios por fotógrafo ---- */
  const [priceByPhotog, setPriceByPhotog] = useState(() => new Map()); // id -> [{min,price}, ...]
  const [loadingPrices, setLoadingPrices] = useState(false);

  // fotógrafos visibles
  const visiblePhotogIds = useMemo(() => {
    const s = new Set((paginatedPhotos || []).map((p) => String(p.photographerId || "")).filter(Boolean));
    return Array.from(s);
  }, [paginatedPhotos]);

  // fetch de photographer_profile (price_lists o precios)
  useEffect(() => {
    let alive = true;
    (async () => {
      if (!visiblePhotogIds.length) return;
      const missing = visiblePhotogIds.filter((id) => !priceByPhotog.has(String(id)));
      if (!missing.length) return;

      setLoadingPrices(true);
      try {
        const { data, error } = await supabase
          .from("photographer_profile")
          .select("user_id, price_lists, precios")
          .in("user_id", missing);
        if (error) throw error;

        const next = new Map(priceByPhotog);
        for (const row of data || []) {
          const lists = Array.isArray(row?.price_lists) ? row.price_lists : [];
          // 1) intentar lista con nombre "Fotos de Domingo", 2) alguna con items, 3) legacy
          const prefer = lists.find((l) => norm(l?.nombre || l?.name) === "fotos de domingo");
          const pick = prefer || lists.find((l) => Array.isArray(l?.items) && l.items.length > 0) || null;
          const tiers = pick ? normalizeTiersFromList(pick) : normalizeTiersLegacy(row?.precios);
          next.set(String(row.user_id), tiers);
        }
        for (const id of missing) if (!next.has(String(id))) next.set(String(id), []);
        if (alive) setPriceByPhotog(next);
      } catch {
        const next = new Map(priceByPhotog);
        for (const id of missing) next.set(String(id), []);
        if (alive) setPriceByPhotog(next);
      } finally {
        if (alive) setLoadingPrices(false);
      }
    })();
    return () => { alive = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [visiblePhotogIds.join(",")]);

  /* ---- conteo seleccionado POR FOTÓGRAFO ---- */
  const selectedIds = selected && typeof selected.size === "number" ? Array.from(selected) : [];
  const photoById = useMemo(() => {
    const map = new Map();
    for (const p of paginatedPhotos || []) map.set(p.id, p);
    return map;
  }, [paginatedPhotos]);

  const selCountByPhotog = useMemo(() => {
    const counts = new Map();
    for (const id of selectedIds) {
      const p = photoById.get(id);
      const pid = p?.photographerId ? String(p.photographerId) : null;
      if (!pid) continue;
      counts.set(pid, (counts.get(pid) || 0) + 1);
    }
    return counts;
  }, [selectedIds.join(","), photoById]);

  // precio unitario (promedio) si agregás ESTA foto — SOLO se muestra si la foto está seleccionada
  const unitPriceFor = (item) => {
    const pid = String(item?.photographerId || "");
    if (!pid) return 50;
    const tiers = priceByPhotog.get(pid) || [];
    const qIfAdd = (selCountByPhotog.get(pid) || 0); // ya seleccionadas de ese fotógrafo
    // acá mostramos el promedio para "q actuales", no forzamos +1 porque la etiqueta aparece cuando ya está seleccionada
    const q = Math.max(1, qIfAdd);
    return perItemAvgForQty(tiers, q);
  };

  // total estimado local (exacto) agrupando por fotógrafo
  const totalExact = useMemo(() => {
    if (!selectedIds.length) return 0;
    const counts = new Map(); // pid -> qty
    for (const id of selectedIds) {
      const ph = photoById.get(id);
      const pid = ph?.photographerId ? String(ph.photographerId) : null;
      if (!pid) continue;
      counts.set(pid, (counts.get(pid) || 0) + 1);
    }
    let sum = 0;
    for (const [pid, qty] of counts.entries()) {
      const tiers = priceByPhotog.get(pid) || [];
      sum += bundleTotalForQty(tiers, qty);
    }
    return Math.round(sum);
  }, [selectedIds.join(","), photoById, priceByPhotog]);

  /* ---- Lightbox ---- */
  const [lbOpen, setLbOpen] = useState(false);
  const [lbIndex, setLbIndex] = useState(0);
  const openLightbox = (idx) => { setLbIndex(idx); setLbOpen(true); };
  const closeLightbox = () => setLbOpen(false);

  const images = useMemo(() => {
    return (paginatedPhotos || []).map((p) => ({
      src: p.url,
      alt: "Foto",
      caption: `${fmtDate(p.timestamp)} ${fmtTime(p.timestamp)} · ${resolvePhotographerName?.(p.photographerId) || ""}`,
      meta: {
        fileName: fileNameFrom(p),
        time: `${fmtDate(p.timestamp)} ${fmtTime(p.timestamp)}`,
        hotspot: resolveHotspotName?.(p.hotspotId) || "",
      },
    }));
  }, [paginatedPhotos, resolvePhotographerName, resolveHotspotName]);

  /* ---- Infinite scroll ---- */
  const sentinelRef = useRef(null);
  useEffect(() => {
    if (!sentinelRef.current) return;
    const io = new IntersectionObserver(
      (entries) => {
        const ent = entries[0];
        if (ent.isIntersecting && hasMorePhotos) onLoadMore?.();
      },
      { root: null, rootMargin: "1200px 0px", threshold: 0.01 }
    );
    io.observe(sentinelRef.current);
    return () => io.disconnect();
  }, [hasMorePhotos, onLoadMore, paginatedPhotos?.length]);

  /* ---- Masonry ---- */
  const columnCount = Math.max(4, Math.min(12, parseInt(cols, 10) || 6));
  const masonryStyle = useMemo(() => ({ columnCount, columnGap: "12px" }), [columnCount]);

  /* ---- Carrito ---- */
  const { addItem, setOpen: openCart, items: cartItems } = useCart();
  const addSelectionToCart = () => {
    if (!selectedIds.length) return;

    // Si alguna ya está en el carrito, no agregamos nada y solo abrimos el carrito
    const inCart = (photo) =>
      Array.isArray(cartItems) && cartItems.some((ci) => String(ci?.id) === String(photo?.id));
    for (const id of selectedIds) {
      const p = photoById.get(id);
      if (p && inCart(p)) {
        openCart?.(true);
        return;
      }
    }

    // agrupar por fotógrafo
    const byPhotog = new Map(); // pid -> array de photo items
    for (const id of selectedIds) {
      const p = photoById.get(id);
      if (!p?.photographerId) continue;
      const pid = String(p.photographerId);
      if (!byPhotog.has(pid)) byPhotog.set(pid, []);
      byPhotog.get(pid).push(p);
    }

    // por clúster, calcular total y prorratear entero
    for (const [pid, arr] of byPhotog.entries()) {
      const tiers = priceByPhotog.get(pid) || [];
      const qty = arr.length;
      const total = Math.round(bundleTotalForQty(tiers, qty));
      const base = Math.floor(total / qty);
      let remainder = total - base * qty;

      for (const p of arr) {
        const perItem = base + (remainder > 0 ? 1 : 0);
        if (remainder > 0) remainder -= 1;

        const phName = resolvePhotographerName?.(p.photographerId) || "Fotógrafo";
        const fname = fileNameFrom(p);
        const label = `Foto • ${phName}`;
        // Fecha desde el resultado (equivale a la fecha buscada si filtraste por día)
        const d = new Date(p.timestamp);
        const fechaStr = isNaN(d)
          ? ""
          : d.toLocaleDateString("es-GT", { year: "numeric", month: "short", day: "2-digit" });
        // Ruta desde el item (si tu backend manda route con cada foto)
        const routeStr = p?.route || "";
        // Nombre del punto usando el resolver (no id)
        const hotspotName = resolveHotspotName?.(p.hotspotId) || "";

        addItem?.({
          id: p.id,
          name: label,
          price: perItem,
          img: p.url,
          qty: 1,
          meta: {
            fecha: fechaStr,
            route: routeStr,
            hotspot: hotspotName,
            fileName: fname,
            photographerId: String(p.photographerId || ""),
            photographerName: phName,
          },
        });
      }
    }

    clearSel?.();
    openCart?.(true);
  };

  return (
    <section className="w-screen ml-[calc(50%-50vw)] px-3 sm:px-6">
      {/* Masonry container */}
      <div style={masonryStyle}>
        {(paginatedPhotos || []).map((item, idx) => {
          const isSel = selected?.has?.(item.id);
          const hsName = resolveHotspotName ? resolveHotspotName(item.hotspotId) : (item.hotspotId || "");
          const phName = resolvePhotographerName?.(item.photographerId) || "—";
          const fname = fileNameFrom(item);
          const perUnit = isSel ? unitPriceFor(item) : null;

          return (
            <article
              key={item.id}
              className={
                "mb-3 break-inside-avoid rounded-xl overflow-hidden bg-white border relative group " +
                (isSel
                  ? "border-blue-600 ring-4 ring-blue-600 shadow-[0_0_0_4px_rgba(59,130,246,0.35)]"
                  : "border-slate-200 hover:shadow-md")
              }
            >
              {/* Checkbox de selección (sin texto). Click = toggle, y NO abre el lightbox */}
              <label
                className="absolute top-2 left-2 z-10 inline-flex items-center gap-2 rounded-md bg-white/90 px-2 py-1 border border-slate-200 shadow-sm cursor-pointer"
                onClick={(e) => e.stopPropagation()}
                title={isSel ? "Quitar de selección" : "Agregar a selección"}
              >
                <input
                  type="checkbox"
                  className="w-4 h-4 accent-blue-600"
                  checked={!!isSel}
                  onChange={() => onToggleSel?.(item.id)}
                />
              </label>

              {/* Foto completa (sin recortar) */}
              <button
                type="button"
                className="w-full text-left bg-slate-100 cursor-zoom-in"
                onClick={() => openLightbox(idx)}
                title="Ver grande"
              >
                <img
                  src={item.url}
                  alt=""
                  loading="lazy"
                  decoding="async"
                  className="w-full h-auto block object-contain"
                  draggable={false}
                />
              </button>

              {/* Info debajo (sin margen superior extra) */}
              {showLabels && (
                <div className="px-2 pb-2 pt-0 text-[12px] leading-tight text-slate-700">
                  <div className="truncate font-extrabold text-slate-900">{phName}</div>
                  <div className="truncate opacity-70">{hsName || "—"}</div>
                  <div className="truncate">{fname}</div>
                </div>
              )}
            </article>
          );
        })}
      </div>

      {/* Sentinel para cargar más */}
      <div ref={sentinelRef} className="h-10" />

      {/* Barra de selección (total exacto local + acciones) */}
      {selectedIds.length > 0 && (
        <div className="sticky bottom-3 z-[1101] mt-3">
          <div className="max-w-[820px] mx-auto rounded-2xl bg-blue-600/95 text-white px-4 py-2.5 flex items-center justify-between text-sm shadow-2xl">
            <div className="truncate">
              <span className="font-semibold">{selectedIds.length}</span> foto{selectedIds.length === 1 ? "" : "s"} seleccionada{selectedIds.length === 1 ? "" : "s"}
              <span className="mx-2 text-white/60">•</span>
              Total estimado: <span className="font-display font-bold">Q{totalExact}</span>
              {loadingPrices ? <span className="ml-2 text-white/70">(cargando precios…)</span> : null}
            </div>
            <div className="flex items-center gap-2">
              <button className="h-9 px-3 rounded-xl bg-white text-blue-700 font-display font-bold" onClick={clearSel}>
                Limpiar
              </button>
              <button
                className="h-9 px-3 rounded-xl bg-emerald-500 text-white font-display font-bold"
                onClick={addSelectionToCart}
                title="Agregar selección al carrito"
              >
                Agregar al carrito
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Lightbox + HUD */}
      {lbOpen && (
        <>
          <PhotoLightbox
            images={images}
            index={lbIndex}
            onIndexChange={setLbIndex}
            onClose={closeLightbox}
            showThumbnails
            captionPosition="header"
            footerSafeArea={72}
            showHeaderClose={false}
            arrowBlue
          />
          <LightboxHUD
            item={paginatedPhotos[lbIndex]}
            resolvePhotographerName={resolvePhotographerName}
            resolveHotspotName={resolveHotspotName}
            selected={selected?.has?.(paginatedPhotos[lbIndex]?.id)}
            onToggleSel={() => onToggleSel?.(paginatedPhotos[lbIndex]?.id)}
            onClose={closeLightbox}
            unitPriceFor={(it) => {
              // En el lightbox mostramos precio SOLO si está seleccionada
              return perItemAvgForQty(priceByPhotog.get(String(it?.photographerId || "")) || [], Math.max(1, selCountByPhotog.get(String(it?.photographerId || "")) || 1));
            }}
          />
        </>
      )}
    </section>
  );
}

/* -------------------- HUD sobre el Lightbox -------------------- */
function LightboxHUD({ item, resolvePhotographerName, resolveHotspotName, selected, onToggleSel, onClose, unitPriceFor }) {
  const { addItem, setOpen } = useCart();
  if (!item) return null;

  const precio = selected ? (unitPriceFor?.(item) ?? 50) : null; // SOLO si está seleccionada
  const phName = resolvePhotographerName?.(item.photographerId) || "Fotógrafo";
  const hotName = resolveHotspotName?.(item.hotspotId) || "Punto";
  const name = `Foto • ${phName}`;

  const agregarCarrito = () => {
    // si no está seleccionada, igual agregamos con el precio unit actual promedio (consistente con grilla)
    const p = Number(unitPriceFor?.(item) ?? 50);
     // meta completa
    const d = new Date(item.timestamp);
    const fechaStr = isNaN(d)
      ? ""
      : d.toLocaleDateString("es-GT", { year: "numeric", month: "short", day: "2-digit" });
    const routeStr = item?.route || "";
    const hotspotName = resolveHotspotName?.(item.hotspotId) || "";
    addItem?.({
      id: item.id,
      name,
      price: precio,
      img: item.url,
      qty: 1,
      meta: {
        fecha: fechaStr,
        route: routeStr,
        hotspot: hotspotName,
        photographerId: String(item.photographerId || ""),
        photographerName: phName,
      },
    });
    setOpen?.(true);
  };

  return (
    <>
      <button
        type="button"
        onClick={onClose}
        className="fixed top-3 right-3 z-[1101] h-9 px-3 rounded-lg bg-red-600 text-white shadow-lg"
        title="Cerrar"
      >
        Cerrar
      </button>

      <div className="fixed left-0 right-0 bottom-0 z-[1101] px-3 pb-3 pointer-events-none">
        <div className="mx-auto max-w-5xl">
          <div className="pointer-events-auto rounded-2xl bg-black/60 backdrop-blur border border-white/15 text-white px-4 py-2.5 flex flex-wrap items-center gap-3">
            <div className="min-w-[220px] grow">
              <div className="text-[13px] leading-tight">
                <span className="font-semibold">{fmtDate(item.timestamp)} {fmtTime(item.timestamp)}</span>
                <span className="mx-2 text-white/60">•</span>
                <span className="">{phName}</span>
                <span className="mx-2 text-white/60">•</span>
                <span className="">{hotName}</span>
                {selected && (
                  <>
                    <span className="mx-2 text-white/60">•</span>
                    <span className="font-display font-bold">Q{Math.round(precio ?? 0)}</span>
                  </>
                )}
              </div>
            </div>
            <div className="flex items-center gap-2 ml-auto">
              <label className={"h-9 px-3 rounded-xl border bg-white text-black font-display font-bold flex items-center gap-2 cursor-pointer " + (selected ? "ring-2 ring-blue-300" : "")}>
                <input
                  type="checkbox"
                  className="w-4 h-4 accent-blue-600"
                  checked={!!selected}
                  onChange={onToggleSel}
                />
                <span>{selected ? "Quitar de selección" : "Agregar a selección"}</span>
              </label>
              <button
                className="h-9 px-3 rounded-xl bg-blue-600 text-white font-display font-bold"
                onClick={agregarCarrito}
              >
                Agregar al carrito
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
