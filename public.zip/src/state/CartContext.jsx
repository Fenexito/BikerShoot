// src/state/CartContext.jsx
import React, {
  createContext,
  useContext,
  useState,
  useMemo,
  Fragment,
  useEffect,
} from "react";
import { createPortal } from "react-dom";
import { supabase } from "../lib/supabaseClient";

const CartContext = createContext(null);
export const useCart = () => useContext(CartContext);

/* ========== Utils ========== */
const fmtQ = (n) =>
  `Q${Math.round(Number(n || 0)).toLocaleString("es-GT", {
    useGrouping: true,
    maximumFractionDigits: 0,
  })}`;

const norm = (s) =>
  String(s || "")
    .normalize("NFD")
    .replace(/\p{Diacritic}/gu, "")
    .trim()
    .toLowerCase();

const toNumberQ = (v) => {
  if (typeof v === "number" && isFinite(v)) return Math.round(v);
  const s = String(v ?? "").replace(/\s+/g, "").replace(/,/g, ".");
  const only = s.replace(/[^\d.]/g, "");
  const n = Number(only);
  return Number.isFinite(n) ? Math.round(n) : NaN;
};

function normalizeTiersLegacy(preciosJson) {
  if (!Array.isArray(preciosJson)) return [];
  const out = [];
  for (const raw of preciosJson) {
    if (!raw || typeof raw !== "object") continue;
    const n = Number(
      raw.n ?? raw.min ?? raw.qty ?? raw.desde ?? raw.cant ?? raw.cantidad ?? NaN
    );
    const pRaw = raw.precio ?? raw.price_q ?? raw.price ?? raw.valor ?? raw.value;
    const p = toNumberQ(pRaw);
    if (!Number.isFinite(p)) continue;
    const min = Number.isFinite(n)
      ? Math.max(1, Math.floor(n))
      : out.length
      ? out[out.length - 1].min + 1
      : 1;
    out.push({ min, price: p });
  }
  out.sort((a, b) => a.min - b.min);
  const compact = [];
  for (const t of out) {
    if (compact.length && compact[compact.length - 1].min === t.min)
      compact[compact.length - 1] = t;
    else compact.push(t);
  }
  return compact;
}

function normalizeTiersFromList(listObj) {
  if (!listObj || typeof listObj !== "object") return [];
  const items = Array.isArray(listObj.items) ? listObj.items : [];
  const tiers = [];
  for (const raw of items) {
    if (!raw || typeof raw !== "object") continue;
    const n = Number(
      raw.n ?? raw.min ?? raw.qty ?? raw.cantidad ?? raw.cant ?? raw.desde ?? NaN
    );
    const pRaw =
      raw.precio ?? raw.price_q ?? raw.price ?? raw.valor ?? raw.value ?? raw.monto;
    const p = toNumberQ(pRaw);
    if (!Number.isFinite(p)) continue;
    const min = Number.isFinite(n)
      ? Math.max(1, Math.floor(n))
      : tiers.length
      ? tiers[tiers.length - 1].min + 1
      : 1;
    tiers.push({ min, price: p });
  }
  tiers.sort((a, b) => a.min - b.min);
  const compact = [];
  for (const t of tiers) {
    if (compact.length && compact[compact.length - 1].min === t.min)
      compact[compact.length - 1] = t;
    else compact.push(t);
  }
  return compact;
}

/* ===== Bundle rules ===== */
function bundleTotalForQty(tiers, q) {
  if (!tiers || !tiers.length) return 50 * Math.max(1, q);
  const qty = Math.max(1, Number(q) || 1);
  const sorted = tiers.slice().sort((a, b) => a.min - b.min);

  const exact = sorted.find((t) => t.min === qty);
  if (exact) return exact.price;

  const first = sorted[0];
  const last = sorted[sorted.length - 1];

  if (qty < first.min) {
    const unit = first.price / first.min;
    return Math.round(unit * qty);
  }

  for (let i = 0; i < sorted.length - 1; i++) {
    const a = sorted[i],
      b = sorted[i + 1];
    if (qty > a.min && qty < b.min) {
      const gap = b.min - a.min;
      const step = (b.price - a.price) / gap;
      return Math.round(a.price + step * (qty - a.min));
    }
  }

  const unit = last.price / last.min;
  return Math.round(unit * qty);
}

function getPhotographerName(item) {
  const metaName =
    item?.meta?.photographerName ||
    item?.meta?.photographer_name ||
    item?.meta?.photographer ||
    "";
  if (metaName) return String(metaName);
  const name = String(item?.name || "");
  const ix = name.indexOf("•");
  if (ix >= 0) return name.slice(ix + 1).trim();
  return "Fotógrafo";
}

function getGroupKey(item) {
  const pid = item?.meta?.photographerId || item?.meta?.photographer_id;
  return pid ? `pid:${pid}` : `name:${getPhotographerName(item)}`;
}

function InfoRow({ label, value }) {
  return (
    <div className="text-[12px] leading-tight">
      <span className="font-semibold text-slate-700">{label}: </span>
      <span className="text-slate-700">{value || "—"}</span>
    </div>
  );
}

/* =================== Provider (SIN dibujar el drawer) =================== */
export function CartProvider({ children }) {
  const [items, setItems] = useState([]);
  const [open, setOpen] = useState(false);
  const [tiersCache, setTiersCache] = useState(() => new Map()); // pid -> tiers

  const ensureTiersForPid = async (pid) => {
    if (!pid) return [];
    if (tiersCache.has(pid)) return tiersCache.get(pid);

    const { data } = await supabase
      .from("photographer_profile")
      .select("user_id, price_lists, precios")
      .eq("user_id", pid)
      .maybeSingle();

    const lists = Array.isArray(data?.price_lists) ? data.price_lists : [];
    const prefer = lists.find(
      (l) => norm(l?.nombre || l?.name) === "fotos de domingo"
    );
    const pick =
      prefer ||
      lists.find((l) => Array.isArray(l?.items) && l.items.length > 0) ||
      null;
    const tiers = pick
      ? normalizeTiersFromList(pick)
      : normalizeTiersLegacy(data?.precios);

    const next = new Map(tiersCache);
    next.set(pid, tiers);
    setTiersCache(next);
    return tiers;
  };

  const repriceGroup = async (pid) => {
    if (!pid) return;
    const tiers = await ensureTiersForPid(pid);

    setItems((prev) => {
      const group = prev.filter(
        (x) => String(x?.meta?.photographerId || "") === String(pid)
      );
      const qty = group.length;
      if (qty <= 0) return prev;

      const total = bundleTotalForQty(tiers, qty);
      const base = Math.floor(total / qty);
      let rem = total - base * qty;

      const next = prev.map((x) => {
        if (String(x?.meta?.photographerId || "") !== String(pid)) return x;
        const perItem = base + (rem > 0 ? 1 : 0);
        if (rem > 0) rem -= 1;
        return { ...x, price: perItem, qty: 1 };
      });
      return next;
    });
  };

  const addItem = (item) => {
    const already = items.some((p) => String(p.id) === String(item.id));
    if (already) {
      setOpen(true);
      return;
    }
    const pid = String(item?.meta?.photographerId || "");
    setItems((prev) => [...prev, { ...item, qty: 1 }]);
    setOpen(true);
    if (pid) repriceGroup(pid);
  };

  const removeItem = (id) => {
    const removed = items.find((x) => String(x.id) === String(id));
    const pid = String(removed?.meta?.photographerId || "");
    setItems((prev) => prev.filter((p) => String(p.id) !== String(id)));
    if (pid) repriceGroup(pid);
  };

  const clear = () => setItems([]);
  const clearGroup = (groupKey) => {
    setItems((prev) => prev.filter((it) => getGroupKey(it) !== groupKey));
  };

  const total = useMemo(
    () => items.reduce((s, x) => s + (Number(x.price) || 0) * (x.qty || 1), 0),
    [items]
  );
  const count = useMemo(
    () => items.reduce((s, x) => s + (x.qty || 1), 0),
    [items]
  );

  const groups = useMemo(() => {
    const map = new Map();
    for (const it of items) {
      const key = getGroupKey(it);
      if (!map.has(key)) {
        map.set(key, { key, name: getPhotographerName(it), items: [], total: 0 });
      }
      const g = map.get(key);
      g.items.push(it);
      g.total += (Number(it.price) || 0) * (it.qty || 1);
    }
    return Array.from(map.values());
  }, [items]);

  const value = {
    items,
    addItem,
    removeItem,
    clear,
    clearGroup,
    total,
    count,
    open,
    setOpen,
  };

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

/* =================== Drawer UI =================== */
function InfoRowBlock({ label, value }) {
  return (
    <div className="text-[12px] leading-tight">
      <span className="font-semibold text-slate-700">{label}: </span>
      <span className="text-slate-700">{value || "—"}</span>
    </div>
  );
}

function DrawerContent({
  open,
  onClose,
  items,
  groups,
  removeItem,
  clear,
  clearGroup,
  total,
}) {
  const overlayClasses = "fixed inset-0 z-[3000] bg-black/70 transition-opacity";
  const panelClasses =
    "fixed right-0 top-0 bottom-0 z-[3001] w-[90vw] max-w-[480px] bg-white shadow-2xl flex flex-col";

  return (
    <Fragment>
      {open && <div className={overlayClasses} onClick={onClose} aria-hidden />}

      <aside
        className={`${panelClasses} ${
          open ? "translate-x-0" : "translate-x-full"
        } transition-transform duration-300`}
        role="dialog"
        aria-modal="true"
        id="biker-cart-drawer"
      >
        {/* Header */}
        <div className="px-4 sm:px-5 py-3 border-b flex items-center justify-between">
          <h2 className="text-base sm:text-lg font-bold text-slate-900">
            Tu carrito {items?.length ? `(${items.length})` : ""}
          </h2>
          <div className="flex items-center gap-2">
            {items?.length > 0 && (
              <button
                className="text-[12px] sm:text-[13px] px-2 py-1 rounded-md bg-slate-100 hover:bg-slate-200 text-slate-700"
                onClick={clear}
                title="Vaciar carrito"
              >
                Vaciar todo
              </button>
            )}
            <button
              className="h-7 w-7 rounded-full bg-red-600 text-white flex items-center justify-center text-[12px]"
              onClick={onClose}
              title="Cerrar"
            >
              ✕
            </button>
          </div>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto px-3 sm:px-4 py-3 space-y-5">
          {(!groups || groups.length === 0) && (
            <div className="text-slate-500 text-sm">
              No tenés fotos en el carrito todavía.
            </div>
          )}

          {groups.map((g) => (
            <section key={g.key} className="border rounded-xl overflow-hidden">
              {/* Encabezado de grupo (fotógrafo) */}
              <div className="px-3 py-2 bg-slate-50 border-b flex items-center justify-between">
                <div className="font-extrabold text-slate-900 truncate">
                  {g.name}
                </div>
                <div className="flex items-center gap-2">
                  <button
                    className="text-[12px] px-2 py-1 rounded-md bg-slate-100 hover:bg-slate-200 text-slate-700"
                    onClick={() => clearGroup(g.key)}
                    title={`Vaciar fotos de ${g.name}`}
                  >
                    Vaciar
                  </button>
                  <div className="text-slate-900 font-bold">{fmtQ(g.total)}</div>
                </div>
              </div>

              {/* Items del grupo */}
              <ul className="divide-y">
                {g.items.map((it) => {
                  const fecha =
                    it?.meta?.fecha ||
                    it?.meta?.time ||
                    it?.meta?.date ||
                    "";
                  const ruta =
                    it?.meta?.route ||
                    it?.meta?.ruta ||
                    it?.meta?.trayecto ||
                    "";
                  let punto = it?.meta?.hotspot || "";
                  if (
                    /^[0-9a-f-]{16,}$/i.test(String(punto)) ||
                    /^\d{3,}$/.test(String(punto))
                  ) {
                    punto = "";
                  }
                  const archivo =
                    it?.meta?.fileName || it?.meta?.filename || "";
                  const totalItem = Math.round(
                    Number(it?.price || 0) * (it?.qty || 1)
                  );

                  return (
                    <li key={it.id} className="p-2 sm:p-3">
                      <div className="flex items-start gap-3">
                        {/* Miniatura cuadrada, foto completa */}
                        {it?.img ? (
                          <div className="w-20 h-20 rounded-md border bg-white flex items-center justify-center overflow-hidden">
                            <img
                              src={it.img}
                              alt=""
                              className="w-full h-full object-contain"
                              loading="lazy"
                              decoding="async"
                            />
                          </div>
                        ) : (
                          <div className="w-20 h-20 rounded-md bg-white border" />
                        )}

                        {/* Info */}
                        <div className="flex-1 min-w-0 pt-0.5">
                          <div className="text-[13px] font-extrabold text-slate-900 truncate">
                            {g.name}
                          </div>
                          <div className="mt-0.5 space-y-0.5">
                            <InfoRow label="Fecha" value={fecha} />
                            <InfoRow label="Ruta" value={ruta} />
                            <InfoRow label="Punto" value={punto} />
                            <InfoRow label="Archivo" value={archivo} />
                          </div>
                        </div>

                        {/* Acciones */}
                        <div className="flex flex-col items-end gap-1">
                          <div className="text-slate-900 font-bold">
                            {fmtQ(totalItem)}
                          </div>
                          <button
                            className="h-5 w-5 rounded-full bg-red-600 text-white flex items-center justify-center text-[10px]"
                            onClick={() => removeItem(it.id)}
                            title="Eliminar esta foto"
                          >
                            ✕
                          </button>
                        </div>
                      </div>
                    </li>
                  );
                })}
              </ul>
            </section>
          ))}
        </div>

        {/* Footer */}
        <div className="px-3 sm:px-4 py-3 border-t bg-white">
          <div className="flex items-center justify-between mb-2.5">
            <div className="text-slate-600 text-sm">Total</div>
            <div className="text-slate-900 font-extrabold text-lg">
              {fmtQ(total)}
            </div>
          </div>
          <button
            className="w-full h-11 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold"
            onClick={() => {
              try {
                window.location.assign("/checkout");
              } catch {}
            }}
          >
            Ir al checkout
          </button>
        </div>
      </aside>
    </Fragment>
  );
}

/* =================== CartDrawerRoot (montalo UNA VEZ en tu app) =================== */
export function CartDrawerRoot() {
  const { items, open, setOpen, total, clear, clearGroup, removeItem } = useCart();
  const groups = useMemo(() => {
    const map = new Map();
    for (const it of items) {
      const key = getGroupKey(it);
      if (!map.has(key)) {
        map.set(key, { key, name: getPhotographerName(it), items: [], total: 0 });
      }
      const g = map.get(key);
      g.items.push(it);
      g.total += (Number(it.price) || 0) * (it.qty || 1);
    }
    return Array.from(map.values());
  }, [items]);

  // Crear (o reusar) un contenedor único en <body> para evitar duplicados
  const [host, setHost] = useState(null);
  useEffect(() => {
    let el = document.getElementById("biker-cart-root");
    if (!el) {
      el = document.createElement("div");
      el.id = "biker-cart-root";
      document.body.appendChild(el);
    }
    setHost(el);
  }, []);

  if (!host) return null;

  return createPortal(
    <DrawerContent
      open={open}
      onClose={() => setOpen(false)}
      items={items}
      groups={groups}
      removeItem={removeItem}
      clear={clear}
      clearGroup={clearGroup}
      total={total}
    />,
    host
  );
}
